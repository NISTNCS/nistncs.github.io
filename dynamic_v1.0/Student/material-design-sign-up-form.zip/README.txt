A Pen created at CodePen.io. You can find this one at https://codepen.io/faizanrupani/pen/jbXPxp.

 Sign Up Form using Material Design on Angular Material JS v1.0.0-rc3.
Material Design Login Form link: http://codepen.io/faizanrupani/pen/QjzMJp

by,
Faizan Anwer Ali Rupani